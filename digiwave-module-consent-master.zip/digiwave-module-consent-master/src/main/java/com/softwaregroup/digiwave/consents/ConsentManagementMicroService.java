package com.softwaregroup.digiwave.consents;

import com.softwaregroup.digiwave.eip.components.servicebus.ServiceProvider;

public class ConsentManagementMicroService extends ServiceProvider {

}
